export { Swiper as SwiperInterface, SwiperOptions } from 'swiper/dist/js/swiper.esm';
