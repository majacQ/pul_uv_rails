import { Animation } from '../../../interface';
/**
 * iOS Action Sheet Enter Animation
 */
export declare const iosEnterAnimation: (AnimationC: Animation, baseEl: HTMLElement) => Promise<Animation>;
