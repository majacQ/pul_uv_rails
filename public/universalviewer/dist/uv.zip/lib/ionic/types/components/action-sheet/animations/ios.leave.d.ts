import { Animation } from '../../../interface';
/**
 * iOS Action Sheet Leave Animation
 */
export declare const iosLeaveAnimation: (AnimationC: Animation, baseEl: HTMLElement) => Promise<Animation>;
