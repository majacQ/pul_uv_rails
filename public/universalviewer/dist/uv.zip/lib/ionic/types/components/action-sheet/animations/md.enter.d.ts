import { Animation } from '../../../interface';
/**
 * MD Action Sheet Enter Animation
 */
export declare const mdEnterAnimation: (AnimationC: Animation, baseEl: HTMLElement) => Promise<Animation>;
