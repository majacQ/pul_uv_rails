import { Animation } from '../../../interface';
/**
 * MD Action Sheet Leave Animation
 */
export declare const mdLeaveAnimation: (AnimationC: Animation, baseEl: HTMLElement) => Promise<Animation>;
